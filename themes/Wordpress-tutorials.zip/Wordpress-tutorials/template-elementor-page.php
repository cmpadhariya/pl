<?php
//Template Name: Elementor Page
get_header();
?>

<?php
the_content();
wp_footer();
?>