<?php
get_header();
?>

<?php
the_content();
get_footer();
