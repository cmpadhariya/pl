<?php

require_once 'components/Updates.php';
